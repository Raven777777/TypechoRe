<?php

namespace Widget\Themes;

use Typecho\Widget;
use Widget\Base;
use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * 风格文件列表组件
 *
 * @author qining
 * @category typecho
 * @package Widget
 * @copyright Copyright (c) 2008 Typecho team (http://www.typecho.org)
 * @license GNU General Public License 2.0
 */
class Files extends Base
{
    /**
     * 当前风格
     *
     * @access private
     * @var string
     */
    private string $currentTheme;

    /**
     * 当前文件
     *
     * @access private
     * @var string
     */
    private string $currentFile;

    /**
     * 执行函数
     *
     * @throws Widget\Exception
     */
    public function execute()
    {
        /** 管理员权限 */
        $this->user->pass('administrator');
        $this->currentTheme = $this->request->filter('slug')->get('theme', Options::alloc()->theme);

        if (
            preg_match("/^([_0-9a-z-. ])+$/i", $this->currentTheme)
            && is_dir($dir = Options::alloc()->themeFile($this->currentTheme))
            && (!defined('__TYPECHO_THEME_WRITEABLE__') || __TYPECHO_THEME_WRITEABLE__)
        ) {
            $files = array_filter(glob($dir . '/*'), function ($path) {
                return preg_match("/\.(php|js|css|vbs)$/i", $path);
            });

            $this->currentFile = $this->request->get('file', 'index.php');

            if (
                preg_match("/^([_0-9a-z-. ])+$/i", $this->currentFile)
                && is_file($dir . '/' . $this->currentFile)
            ) {
                foreach ($files as $file) {
                    if (is_file($file)) {
                        $file = basename($file);
                        $this->push([
                            'file'    => $file,
                            'theme'   => $this->currentTheme,
                            'current' => ($file == $this->currentFile)
                        ]);
                    }
                }

                return;
            }
        }

        throw new Widget\Exception('风格文件不存在', 404);
    }

    /**
     * 判断是否拥有写入权限
     *
     * @return bool
     */
    public static function isWriteable(): bool
    {
        return (!defined('__TYPECHO_THEME_WRITEABLE__') || __TYPECHO_THEME_WRITEABLE__)
            && !Options::alloc()->missingTheme;
    }

    /**
     * 判断文件是否属于允许编辑的白名单
     *
     * 与编辑器 UI 侧 (execute) 使用相同的字符白名单,
     * 供 action 端点统一复用, 防止路径穿越写入
     *
     * @param string $theme 外观名称
     * @param string $file 文件名
     * @return bool
     */
    public static function isEditableFile(string $theme, string $file): bool
    {
        if (!preg_match("/^([_0-9a-z-. ])+$/i", $theme)
            || !preg_match("/^([_0-9a-z-. ])+$/i", $file)
            || (!defined('__TYPECHO_THEME_WRITEABLE__') || __TYPECHO_THEME_WRITEABLE__) === false
        ) {
            return false;
        }

        $dir = Options::alloc()->themeFile($theme);
        $realDir = realpath($dir) ?: '';
        $realFile = realpath($dir . '/' . $file) ?: '';

        return '' !== $realDir && '' !== $realFile
            && is_dir($realDir)
            && 0 === strpos($realFile, $realDir . DIRECTORY_SEPARATOR)
            && is_file($realFile);
    }

    /**
     * 获取菜单标题
     *
     * @return string
     */
    public function getMenuTitle(): string
    {
        return _t('编辑文件 %s', $this->currentFile);
    }

    /**
     * 获取文件内容
     *
     * @return string
     */
    public function currentContent(): string
    {
        $file = Options::alloc()->themeFile($this->currentTheme, $this->currentFile);

        if (!is_file($file) || !is_readable($file)) {
            return '';
        }

        return htmlspecialchars((string)file_get_contents($file), ENT_QUOTES, 'UTF-8');
    }

    /**
     * 获取文件是否可读
     *
     * @return bool
     */
    public function currentIsWriteable(): bool
    {
        return is_writable(Options::alloc()
                ->themeFile($this->currentTheme, $this->currentFile))
            && self::isWriteable();
    }

    /**
     * 获取当前文件
     *
     * @return string
     */
    public function currentFile(): string
    {
        return $this->currentFile;
    }

    /**
     * 获取当前风格
     *
     * @return string
     */
    public function currentTheme(): string
    {
        return $this->currentTheme;
    }
}
